# Quality Gates

本文件记录当前仓库的质量门禁、hooks 策略、阻断规则和豁免方式。命令变化时同步更新 `docs/commands.md` 和 `docs/testing.md`。

## 目标

- 让 Codex 和人工开发在提交前运行合适的验证。
- 把低成本、高确定性的检查前移。
- 避免 hooks 误触发破坏性、慢速、外部依赖或需要凭证的操作。
- V3.1 只增加 hook 质量纪律和候选审查，不默认启用新的阻断 hook stack。

## 当前状态

- Codex hooks：
- Git hooks / pre-commit：
- CI required checks：
- 本地质量门禁脚本：

如果当前没有启用 hooks，写：未启用；按本文手动选择验证命令。

## 门禁分层

### Level 0：文档化门禁

适用于所有仓库。Codex 根据 `AGENTS.md`、`docs/commands.md`、`docs/testing.md` 和本文选择验证命令。

- 触发：
- 命令：
- 是否阻断：

### Level 1：快速本地门禁

适合放入 hooks 的检查。必须快速、确定、无外部依赖、无写入副作用。

- Context pack / 文档门禁：
- 格式检查：
- Lint：
- 类型检查：
- 针对性单元测试：按受影响范围选择，不要求每次全部运行；优先记录稳定、短耗时、无外部依赖、无业务数据写入的测试子集。
- 轻量安全检查：

只有 A 级无写入/低副作用命令适合默认进入 hooks。会写 ignored 报告的 B 级命令、会触发应用生命周期的 C 级命令、会访问外部服务或写业务数据的 D 级命令，都不要默认放入 hooks。

### Hooks 候选集

先文档化候选集，不自动启用。启用前逐条确认耗时、稳定性和副作用。

| 候选命令 | 等级 | 是否可默认阻断 | 原因 / 条件 |
|---|---|---|---|
| context pack verifier | A | 是 | 只检查文档结构、命令写法、敏感模式和引用 |
| 稳定的针对性单元测试 | A | 条件允许 | 必须按受影响范围选择，短耗时、无外部依赖、无业务数据写入；连续多次真实任务验证后再晋升为明确候选 |
| 静态文档契约测试 | A | 条件允许 | 适合保护安装说明、路径引用、命令示例、README 安全约束和 repo policy 标记；必须是窄范围、无网络、无写入的 repo-specific 测试 |
| lint / typecheck | A | 条件允许 | 确认不会写缓存或修改文件 |
| compile / compileall | A 或 B | 谨慎 | 很多语言/工具会写缓存、bytecode 或 build 目录；确认后再放入 hook |
| coverage / 静态报告 / 截图 / trace | B | 不默认 | 会写 ignored 报告，适合人工触发或标准交付门禁 |
| app health / TestClient / dev server smoke | C | 不默认 | 可能触发应用生命周期、本地 DB、缓存、端口或后台任务 |
| 外部服务 / 迁移 / 部署 / 真实数据写入 | D | 禁止 | 需要用户确认或专门环境 |

### V3.1 Hook Review Checklist

每个 hook 候选启用前必须记录：

- trigger event：
- command：
- max runtime：
- read/write behavior：
- output/cache/report location：
- failure mode：advisory / fail-open / blocking
- false-positive risk：
- bypass/disable path：
- first-run review：
- owner/maintenance path：

默认从 advisory/fail-open 开始。blocking 只用于快速、确定、低误报、有清晰修复路径、无网络、无凭证、无业务数据写入的检查。

优先候选是 read-only hygiene 和文档契约检查，例如 private path、secret-like pattern、危险生产命令提示、context pack 结构、命令示例漂移。即使是这些候选，也必须先文档化，不自动安装。

### Level 2：标准交付门禁

适合 Codex 完成实现后主动运行，或由人工在提交/PR 前运行。

- 全量单元测试：
- 集成测试：
- 构建：
- 前端 preview / smoke：
- 关键 API smoke：

### Level 3：高风险门禁

适合 CI、发布前或用户明确批准后运行。

- E2E：
- 迁移 dry-run：
- 性能/负载：
- 安全扫描：
- 真实外部服务验证：

## 改动类型矩阵

| 改动类型 | 最小门禁 | 推荐门禁 | 禁止自动 hook |
|---|---|---|---|
| 文档 / context pack | context pack verifier | 文档路径/引用检查、相关 verifier 测试、静态文档契约测试 | 联网链接检查、自动写入用户项目 |
| 单元逻辑 | 受影响模块的针对性单元测试 | 更大范围单元测试、lint/typecheck | 外部服务、业务数据写入 |
| API/服务端 | 受影响 router/service 的针对性测试 | app health 或集成测试，先确认生命周期副作用 | 真实外部服务写入 |
| 数据模型 | 数据模型/存储层针对性测试 | 全量测试、迁移 dry-run | 迁移、清库、真实数据写入 |
| 前端 UI | 前端契约测试或组件测试 | browser smoke、截图、E2E | 自动启动长期服务、写大量报告 |
| 样式/响应式 | 受影响页面的 browser smoke | 多 viewport 截图、视觉回归 | 未确认输出目录的截图/trace |
| 权限/安全 | 单元测试、静态检查 | 用户确认后的专门验证 | 真实账号、权限、密钥变更 |
| 构建/配置 | 静态检查、lint/typecheck | build 或 preview smoke | 部署、生产配置变更 |
| 依赖升级 | lock diff review、测试子集 | 全量测试、构建 | 自动安装/升级依赖 hook |
| 数据库迁移 | migration lint 或 dry-run | 专门环境验证 | 生产迁移、清库 |
| 性能敏感路径 | 微基准或针对性性能测试 | 专门 profile | 默认 hook 里的长耗时压测 |

## 副作用矩阵

| 等级 | 可进入默认 hook | 需要说明 | 典型命令 |
|---|---|---|---|
| A：无写入/低副作用 | 可以 | 运行时间和失败处理 | context pack verifier、lint、类型检查、针对性纯单元测试 |
| B：写 ignored 报告 | 谨慎 | 输出目录、是否已忽略、清理方式 | coverage、静态扫描报告、截图、trace |
| C：触发应用生命周期 | 不默认 | 本地 DB、缓存、调度器、端口、后台服务影响 | TestClient app health、dev server smoke、preview server |
| D：外部服务/数据写入 | 禁止默认 | 凭证、网络、生产/交易/迁移/权限影响 | 数据同步、部署、迁移、真实交易、外部 LLM 联调 |

## Hooks 策略

默认不启用阻断型 hooks。启用前必须确认：

- hook 会在什么事件触发。
- hook 会运行哪些命令。
- hook 最大运行时间和超时行为。
- 是否会修改文件。
- 是否会写 cache、bytecode、coverage、report、trace、截图、索引或 build 产物。
- 是否访问网络、凭证、数据库、生产系统或外部服务。
- 失败时如何修复或豁免。
- hook 配置是否已被 review 和信任。
- hook 是否已经在真实任务中产生重复收益，而不是只增加流程噪音。

## 禁止放入 hooks

- 自动格式化写入，除非项目明确采用且不会覆盖用户改动。
- 安装依赖、升级依赖、修改锁文件。
- 数据库迁移、数据写入、清空缓存、重建生产索引。
- 部署、发布、推送、创建 PR、合并、打 tag。
- 访问生产系统、支付、账单、账号、权限、密钥。
- 需要真实外部服务且不可稳定复现的命令。
- 会启动应用生命周期并写本地数据库、缓存或报告的 health check，除非项目明确接受并记录了副作用。
- LLM 判断、自动 memory 写入、自动学习全局规则、后台 watcher、dashboard 或长期 daemon。
- 未经审查的外部脚本、curl-to-shell、全局路径写入或读浏览器/cookie/账号状态的命令。

## External Component Gate

准备把外部 skill、plugin、MCP、hook、subagent 模式、脚本或模板接入当前仓库前，先做外部组件准入审查：

- 结果只允许 `promote`、`pilot`、`repo-local`、`hold`、`reject`。
- `promote` 表示吸收规则、文档、只读检查或窄触发能力，不表示安装或启用。
- `pilot` 必须有 baseline、权限级别、退出条件和回滚方式。
- license、auth、side-effect、daemon、network、install、Superpowers overlap、private-data 风险必须显式记录。

未经准入审查的外部组件不得进入 hooks、CI、MCP 配置、全局 Codex 配置或默认验证路径。

## 失败处理

1. 记录失败命令和关键输出。
2. 判断是否由当前改动引起。
3. 使用 `debug-loop` 做最小修复。
4. 复测同一门禁。
5. 如果是既有失败或环境缺失，在最终回复中说明证据、影响和未验证风险。

## 豁免规则

- 豁免原因：
- 允许谁批准：
- 需要补跑的后续验证：
- 记录位置：

## 待确认

-
