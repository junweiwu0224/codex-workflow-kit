# V2 Adoption Evidence

本文件记录 Codex Workflow Kit V2 采用计划的当前证据。目标是让每个晋升、拒绝和暂缓决定都有可审计依据，而不是凭主观感觉扩大默认自动化。

## Baseline Verification

已验证的 V2 baseline：

```bash
python3 scripts/verify_toolkit.py
# Workflow toolkit OK

/Users/wujunwei/Desktop/ai-quant-trading/.venv/bin/python -m pytest -p no:cacheprovider tests/test_verify_toolkit.py -q
# 24 passed

cd repo-template
python3 scripts/verify_context_pack.py
# Context pack OK

/Users/wujunwei/Desktop/ai-quant-trading/.venv/bin/python -m pytest -p no:cacheprovider tests/test_verify_context_pack.py -q
# 12 passed

cd releases
env LC_ALL=C LANG=C LC_CTYPE=C shasum -a 256 -c codex-workflow-kit-2026.06.07.1.tar.gz.sha256
# codex-workflow-kit-2026.06.07.1.tar.gz: OK
```

临时解包演练：

```text
Workflow toolkit OK
Context pack OK
repo-only dry-run/install completed against a temporary repo
```

## Trial Repo Scan

只读扫描找到 5 个候选仓库：

| Repo | Shape | Existing context | Dry-run result | Current decision |
|---|---|---|---|---|
| `/Users/wujunwei/Desktop/ai-quant-trading` | Python + frontend/dashboard | 已有 `AGENTS.md` 和 context docs | `AGENTS.md` conflict | Use as evidence source; do not overwrite |
| `/Users/wujunwei/Desktop/coze-studio` | Go backend repo | No root context pack found | Dirty worktree; can create repo context pack after review | Manual merge until local changes are reviewed |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Docs/tooling repo | No context pack found | Can create repo context pack | Candidate for approved repo-only install |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify` | Large multi-package app | Existing root and nested `AGENTS.md` files | `AGENTS.md` conflict | Manual merge only; no mechanical install |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Go service/plugin daemon | No context pack found | Can create repo context pack | Candidate for approved repo-only install |

只读 adoption audit 命令：

```bash
python3 scripts/audit_repo_adoption.py /path/to/repo
python3 scripts/audit_repo_adoption.py --json /path/to/repo-a /path/to/repo-b
```

该脚本只读取目标 repo，输出 `repo-only-install` 或 `manual-merge` 建议，不复制模板、不写文件、不创建备份。`--json` 输出用于批量 adoption 和后续自动化评估。

当前 audit 结果：

| Repo | Recommendation | Findings |
|---|---|---|
| `/Users/wujunwei/Desktop/ai-quant-trading` | `manual-merge` | Dirty worktree, existing context files, existing `AGENTS.md`, and `docs/ARCHITECTURE.md` case-equivalent architecture doc |
| `/Users/wujunwei/Desktop/coze-studio` | `manual-merge` | Dirty worktree |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | `repo-only-install` | 0 |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify` | `manual-merge` | Dirty worktree and existing root `AGENTS.md`; nested `AGENTS.md` files should stay untouched |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | `repo-only-install` | 0 |

## Real Usage Evidence

`/Users/wujunwei/Desktop/ai-quant-trading/docs/codex-usage.md` already contains:

- Context pack onboarding evidence.
- Quality gate side-effect calibration.
- Hooks candidate design.
- Subagents parallel boundary calibration.
- Five real implementation task records.
- Phase reviews after representative tasks.

Reusable signals from that repo:

- `scripts/verify_context_pack.py` is a strong A-level low-side-effect gate.
- Targeted pytest works best when selected by affected scope.
- Report-writing scans and TestClient/app health checks should not be default hooks.
- Subagents help in read-only or disjoint-ownership work, but should not become default implementation behavior.
- Small frontend JS contract changes can often use Node/pytest contract tests; layout/CSS/interaction risk still needs browser QA.

## Promotions

Promoted into V2:

- `install.sh --repo-only`
  - Evidence: multi-repo dry-run showed global AGENTS/skills checks create noise when only repo context pack is needed.
  - Validation: `test_install_repo_only_skips_global_files`; temporary release install drill.
  - Boundary: requires `--repo PATH`; skips global writes.

- `scripts/audit_repo_adoption.py`
  - Evidence: external repo adoption needs a reusable read-only preflight before writing context pack files.
  - Validation: `tests/test_audit_repo_adoption.py` including dirty worktree detection and machine-readable `--json` output.
  - Boundary: read-only audit; does not replace `install.sh --dry-run`.

- `docs/architecture.md` as a required context pack file
  - Evidence: quickstart and template assume architecture docs exist, but verifier did not enforce it.
  - Validation: `test_check_context_pack_requires_architecture_document`.
  - Boundary: checks only context pack completeness; does not validate architecture quality.

## Rejections

Rejected as V2 defaults:

- Blocking hooks by default.
  - Reason: evidence supports documentation and candidate evaluation, not automatic repo-wide blocking.

- MCP/code graph/memory by default.
  - Reason: current evidence shows repo docs, `rg`, language tools and targeted tests solve most observed context problems.

- Subagents as default implementation mode.
  - Reason: subagents are useful with clear ownership, but shared files, lifecycle, schemas and product semantics remain main-agent controlled.

- Browser QA for every frontend change.
  - Reason: pure JS contract changes can be validated cheaply; browser QA remains required for layout, CSS, interaction, route, media, canvas/chart or viewport risk.

## Deferred Work

Needs explicit user approval before continuing:

```text
./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows --backup
./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon --backup
```

Current safer install candidates based on dirty-worktree-aware audit:

```text
/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows
/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon
```

`/Users/wujunwei/Desktop/coze-studio` should be reviewed first because it has uncommitted changes.

After its local changes are reviewed, rerun:

```bash
python3 scripts/audit_repo_adoption.py /Users/wujunwei/Desktop/coze-studio
```

After approved installation, run in each repo:

```bash
python3 scripts/verify_context_pack.py
```

Then add a baseline row to each repo's `docs/codex-usage.md` and continue with real M/L/XL task records.

## Current V2 Status

`2026.06.07.1` is a verified V2 adoption package with two evidence-backed improvements and a documented adoption decision trail. It is not yet the full end-state of the V2 plan because external repo installation and multi-repo real task records still require explicit approval.
