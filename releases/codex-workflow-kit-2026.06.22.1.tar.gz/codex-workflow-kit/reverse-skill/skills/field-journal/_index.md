# 项目经验索引

> 本文件用于在新任务开始前快速检索历史经验。
> 带 `[种子]` 标记的条目是预置参考案例，不计入真实完成项目。
> 真实项目使用日期文件名（例如 `2026-05-16_*`），种子案例使用 `seed-*`。

## 统计

- 真实项目数：16
- 种子参考数：17
- 总条目数：33

## 按场景分类

### APK / Android 逆向

- [2026-05-15-cellular-pro-mumu-ksad-fragment-fix](./2026-05-15-cellular-pro-mumu-ksad-fragment-fix.md)
- [[种子] seed-008_apk-okhttp-ssl-pin-bypass](./seed-008_apk-okhttp-ssl-pin-bypass.md)

### 二进制 / 固件 / CTF
- [2026-06-14_reverse-skill-full-verification](./2026-06-14_reverse-skill-full-verification.md)
- [2026-06-15_claude-v32-plugin-radare2-verification](./2026-06-15_claude-v32-plugin-radare2-verification.md)
- [2026-06-15_openaiworld-loader-license-trace](./2026-06-15_openaiworld-loader-license-trace.md)
- [2026-06-16_guyun-manifesthub-source-recovery](./2026-06-16_guyun-manifesthub-source-recovery.md)
- [2026-06-16_openaiworld-melonloader-ui-close-init-hang](./2026-06-16_openaiworld-melonloader-ui-close-init-hang.md)
- [2026-06-16_openaiworld-partial-unlock-90107](./2026-06-16_openaiworld-partial-unlock-90107.md)
- [2026-06-16_openaiworld_f2_modifier_menu_bridge](./2026-06-16_openaiworld_f2_modifier_menu_bridge.md)
- [2026-06-16_openaiworld-base-feature-gate-90110](./2026-06-16_openaiworld-base-feature-gate-90110.md)
- [2026-06-16_openaiworld-feature-settings-gate-90111](./2026-06-16_openaiworld-feature-settings-gate-90111.md)

- [2026-05-15_lumine-go-reverse](./2026-05-15_lumine-go-reverse.md)
- [2026-06-13_ghidra-bin-cat-headless-mcp-verification](./2026-06-13_ghidra-bin-cat-headless-mcp-verification.md)
- [[种子] seed-001_elf-packed-loader](./seed-001_elf-packed-loader.md)
- [[种子] seed-002_go-malware-stripped](./seed-002_go-malware-stripped.md)
- [[种子] seed-010_ctf-pwn-rop-x64](./seed-010_ctf-pwn-rop-x64.md)
- [[种子] seed-011_pcap-protocol-reverse](./seed-011_pcap-protocol-reverse.md)
- [[种子] seed-014_unity-il2cpp-reverse](./seed-014_unity-il2cpp-reverse.md)
- [[种子] seed-015_iot-firmware-uart](./seed-015_iot-firmware-uart.md)

### Web / API / 渗透测试

- [2026-05-16_pentest-personalblog-fun-mass-assignment](./2026-05-16_pentest-personalblog-fun-mass-assignment.md)
- [2026-05-17_pentest-vue-spa-actuator-leak](./2026-05-17_pentest-vue-spa-actuator-leak.md)
- [2026-05-25_pentest-cf-access-sibling-subdomain-cookie-poisoning](./2026-05-25_pentest-cf-access-sibling-subdomain-cookie-poisoning.md)
- [2026-05-26_pentest-newapi-rate-limit-bypass](./2026-05-26_pentest-newapi-rate-limit-bypass.md)
- [2026-06-19_codex-referral-repos-static-analysis](./2026-06-19_codex-referral-repos-static-analysis.md)
- [[种子] seed-003_web-api-auth-bypass](./seed-003_web-api-auth-bypass.md)
- [[种子] seed-004_js-sign-webpack](./seed-004_js-sign-webpack.md)
- [[种子] seed-006_ssrf-cloud-metadata](./seed-006_ssrf-cloud-metadata.md)
- [[种子] seed-017_xxe-oob-exfil](./seed-017_xxe-oob-exfil.md)

### 企业内网 / 云安全

- [[种子] seed-005_ad-certipy-esc1](./seed-005_ad-certipy-esc1.md)
- [[种子] seed-007_ntlm-relay-coercer](./seed-007_ntlm-relay-coercer.md)
- [[种子] seed-013_kerberoasting-spn](./seed-013_kerberoasting-spn.md)
- [[种子] seed-016_k8s-container-escape](./seed-016_k8s-container-escape.md)

### iOS 逆向

- [[种子] seed-009_ios-jailbreak-detect-bypass](./seed-009_ios-jailbreak-detect-bypass.md)

### 其他

- [[种子] seed-012_log4shell-jndi-rce](./seed-012_log4shell-jndi-rce.md)

## 使用说明

1. 新任务开始前，先按场景分类查找是否有相似记录。
2. 命中真实项目时，优先复用已验证的流程和踩坑记录。
3. 命中种子案例时，只作为方法参考，不视为真实成功记录。
4. 新增经验后，请按 PR 流程更新本索引，避免直接改动共享主线。
