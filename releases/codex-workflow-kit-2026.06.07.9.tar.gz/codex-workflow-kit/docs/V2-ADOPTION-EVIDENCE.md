# V2 Adoption Evidence

本文件记录 Codex Workflow Kit V2 采用计划的当前证据。目标是让每个晋升、拒绝和暂缓决定都有可审计依据，而不是凭主观感觉扩大默认自动化。

## Baseline Verification

已验证的 V2 baseline：

```bash
python3 scripts/verify_toolkit.py
# Workflow toolkit OK

/Users/wujunwei/Desktop/ai-quant-trading/.venv/bin/python -m pytest -p no:cacheprovider tests/test_audit_repo_adoption.py tests/test_render_usage_row.py tests/test_verify_toolkit.py -q
# 45 passed

cd repo-template
python3 scripts/verify_context_pack.py
# Context pack OK

/Users/wujunwei/Desktop/ai-quant-trading/.venv/bin/python -m pytest -p no:cacheprovider tests/test_verify_context_pack.py -q
# 12 passed

cd releases
env LC_ALL=C LANG=C LC_CTYPE=C shasum -a 256 -c codex-workflow-kit-2026.06.07.9.tar.gz.sha256
# codex-workflow-kit-2026.06.07.9.tar.gz: OK
```

`2026.06.07.9` 临时解包演练：

```text
Workflow toolkit OK
global dry-run/install completed against temporary Codex and agents homes
installed AGENTS.md and repo-onboarding skill verified
repo-only dry-run/install completed against a temporary repo
Context pack OK
baseline usage row appended and found in docs/codex-usage.md
```

## Trial Repo Scan

只读扫描找到 5 个候选仓库：

| Repo | Shape | Existing context | Dry-run result | Current decision |
|---|---|---|---|---|
| `/Users/wujunwei/Desktop/ai-quant-trading` | Python + frontend/dashboard | 已有 `AGENTS.md` 和 context docs | `AGENTS.md` conflict | Use as evidence source; do not overwrite |
| `/Users/wujunwei/Desktop/coze-studio` | Go backend repo | No root context pack found | Dirty worktree; can create repo context pack after review | Manual merge until local changes are reviewed |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Docs/tooling repo | V2 context pack installed and repo-specific calibration completed | `Context pack OK` | Ready for real workflow doc task records |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify` | Large multi-package app | Existing root and nested `AGENTS.md` files | `AGENTS.md` conflict | Manual merge only; no mechanical install |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Go service/plugin daemon | V2 context pack installed and repo-specific calibration completed | `Context pack OK` | Ready for real code task records; Go tests remain manual-only by repo policy |

只读 adoption audit 命令：

```bash
python3 scripts/audit_repo_adoption.py /path/to/repo
python3 scripts/audit_repo_adoption.py --json /path/to/repo-a /path/to/repo-b
python3 scripts/audit_repo_adoption.py --markdown /path/to/repo-a /path/to/repo-b
```

该脚本只读取目标 repo，输出 `repo-only-install` 或 `manual-merge` 建议，不复制模板、不写文件、不创建备份。`--json` 输出用于批量 adoption 和后续自动化评估；`--markdown` 输出可直接粘贴为 adoption evidence 表格，减少手工整理误差。

Baseline usage row 生成命令：

```bash
python3 scripts/render_usage_row.py baseline
python3 scripts/render_usage_row.py baseline --verification-command ".venv/bin/python scripts/verify_context_pack.py"
```

该脚本只打印 Markdown 表格行，不写目标 repo。安装和验证 context pack 后，可把输出追加到目标 repo 的 `docs/codex-usage.md`，减少多 repo 首次采用记录的手工漂移。

安装前 audit 结果：

| Repo | Recommendation | Findings | Command |
|---|---|---|---|
| `/Users/wujunwei/Desktop/ai-quant-trading` | `manual-merge` | `architecture-case-match`, `dirty-worktree`, `existing-agents`, `existing-context-file` x12 | `./install.sh --repo-only --repo /Users/wujunwei/Desktop/ai-quant-trading --backup` |
| `/Users/wujunwei/Desktop/coze-studio` | `manual-merge` | `dirty-worktree` | `./install.sh --repo-only --repo /Users/wujunwei/Desktop/coze-studio --backup` |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | `repo-only-install` | 0 | `./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows --backup` |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify` | `manual-merge` | `dirty-worktree`, `existing-agents` | `./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify --backup` |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | `repo-only-install` | 0 | `./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon --backup` |

安装和校准后再次 audit，两个已落地 repo 会因为已有 `AGENTS.md`、context docs 和 dirty worktree 正确返回 `manual-merge`。这表示后续更新应人工合并，而不是重复机械安装。

## Real Usage Evidence

`/Users/wujunwei/Desktop/ai-quant-trading/docs/codex-usage.md` already contains:

- Context pack onboarding evidence.
- Quality gate side-effect calibration.
- Hooks candidate design.
- Subagents parallel boundary calibration.
- Five real implementation task records.
- Phase reviews after representative tasks.

Reusable signals from that repo:

- `scripts/verify_context_pack.py` is a strong A-level low-side-effect gate.
- Targeted pytest works best when selected by affected scope.
- Report-writing scans and TestClient/app health checks should not be default hooks.
- Subagents help in read-only or disjoint-ownership work. They should not become unconditional implementation behavior, but L/XL, planned, cross-module, multi-failure or multi-file-review tasks now require a proactive suitability check and active dispatch when 2+ independent non-overlapping subtasks exist.
- Small frontend JS contract changes can often use Node/pytest contract tests; layout/CSS/interaction risk still needs browser QA.

External repo baseline installs completed after explicit user approval:

| Repo | Verification | Usage record | Git status |
|---|---|---|---|
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | `python3 scripts/verify_context_pack.py` -> Context pack OK | Baseline row added to `docs/codex-usage.md` | New context pack files only |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | `python3 scripts/verify_context_pack.py` -> Context pack OK | Baseline row added to `docs/codex-usage.md` | New context pack files only |

Repo-specific onboarding calibration completed after baseline install:

| Repo | Calibration | Verification | Reusable signal |
|---|---|---|---|
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Replaced generic app-template assumptions with docs-only workflow repo facts in `AGENTS.md` and context docs | `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Lightweight docs/tooling repos should keep commands and gates focused on Markdown/context verification rather than app/build assumptions |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Replaced generic template assumptions with Go daemon/CLI facts, runtime boundaries, CI commands, generated-code boundaries, and manual-only test policy | `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Repo policy can override default Codex verification behavior; record exact Go test commands but do not run them automatically when project docs prohibit it |

Real M-level tasks after repo-specific calibration:

| Repo | Task | Verification | Reusable signal |
|---|---|---|---|
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Align Go version docs with go.mod/CI by updating stale `CLAUDE.md` Go version from `1.23.3` to `1.26.2` and cleaning context pack stale-version notes | `rg -n "1\\.23\\.3|1\\.26\\.2|Go [0-9]|go-version|go 1\\." README.md CLAUDE.md AGENTS.md docs go.mod .github/workflows`; `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Context pack successfully surfaced a stale project doc fact; Go tests were intentionally not run because repo policy forbids automatic tests |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Guard README agent instruction append snippets so Claude/Codex setup commands detect an existing `## Code changes` section before appending and show a scoped `git diff` review | `pytest tests/test_readme_install_safety.py -q` red -> green; `pytest tests/test_verify_context_pack.py tests/test_readme_install_safety.py -q` -> 14 passed; `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Docs-only workflow repos benefit from tiny static content-contract tests; no need to promote full Markdown lint yet |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Lock manual-only Go test policy with static docs test by adding `manual-only-test-policy` markers to project docs and a Python policy test | `pytest tests/test_manual_test_policy.py -q` red -> green; `pytest tests/test_verify_context_pack.py tests/test_manual_test_policy.py -q` -> 15 passed; `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | The most important hook boundary is now test-protected without running Go tests, Docker services, daemon startup, or migrations |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Validate CLAUDE.md repo paths with static docs test by fixing stale architecture paths, real package test examples, and shell block path drift | `pytest tests/test_claude_doc_paths.py -q` red -> green; `pytest tests/test_verify_context_pack.py tests/test_manual_test_policy.py tests/test_claude_doc_paths.py -q` -> 16 passed; `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Static docs/path tests can protect high-value repo guidance without running Go tests, Docker services, daemon startup, or migrations |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Make raw workflow downloads fail fast by changing README raw workflow install commands from `curl -L` to `curl --fail --location --show-error` and locking the rule with a static README test | `pytest tests/test_readme_install_safety.py::test_raw_workflow_download_commands_fail_fast -q` red -> green; `pytest tests/test_verify_context_pack.py tests/test_readme_install_safety.py -q` -> 15 passed; `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Static README content-contract tests caught an install safety issue that full Markdown lint would not specifically protect |

## First Adoption Review

结论基于两个已校准外部 repo 的 3 条真实 M 级任务记录：

- `dify-plugin-daemon`: Align Go version docs with go.mod/CI。
- `ai-workflows`: Guard README agent instruction append snippets。
- `dify-plugin-daemon`: Lock manual-only Go test policy with static docs test。

Promote now:

- Keep `python3 scripts/verify_context_pack.py` as the default A-level context pack gate.
- Promote tiny static docs/content-contract tests as repo-specific gate candidates when they protect a repeated operational rule, such as README install safety or manual-only test policy.
- Keep `scripts/audit_repo_adoption.py` and `scripts/render_usage_row.py` as V2 default toolkit helpers because they reduced multi-repo adoption drift.

Keep documented, not default:

- Go tests, integration tests, benchmarks, daemon startup, migrations, build scripts, install scripts, and release/publish actions remain manual-only for `dify-plugin-daemon`.
- Markdown lint/link checking remains a candidate for `ai-workflows`, but the current evidence supports narrow static tests over full Markdown lint.
- Subagents remain useful for read-only or clearly partitioned work. They should not become unconditional implementation mode, but large/planned/cross-module work must actively assess and use them when the split is safe.
- Browser/frontend QA remains conditional; neither calibrated repo produced browser/UI evidence in this review.

Reject as default for this V2 checkpoint:

- Blocking hooks by default.
- MCP/code graph/memory by default.
- `go test` in default hooks for repositories whose project docs prohibit automatic tests.

Next review trigger:

- Satisfied by the fourth and fifth calibrated-repo task records below; see Second Adoption Review.

## Second Adoption Review

结论基于两个已校准外部 repo 的 5 条真实 M 级任务记录：

- `dify-plugin-daemon`: Align Go version docs with go.mod/CI。
- `ai-workflows`: Guard README agent instruction append snippets。
- `dify-plugin-daemon`: Lock manual-only Go test policy with static docs test。
- `dify-plugin-daemon`: Validate CLAUDE.md repo paths with static docs test。
- `ai-workflows`: Make raw workflow downloads fail fast。

Promote now:

- Keep `python3 scripts/verify_context_pack.py` as the default A-level context pack gate.
- Promote static docs/content-contract tests as repo-specific quality gate candidates when they protect high-value operational rules: install snippets, raw download safety, documented repo paths, command examples, generated-code boundaries, or manual-only test policy markers.
- Update the repo-template quality gate/testing guidance to name `静态文档契约测试` explicitly, so new repos can adopt narrow tests without pulling in full Markdown lint/link-checking by default.

Keep documented, not default:

- Blocking hooks remain opt-in per repo. The evidence supports documenting A-level candidates, not enabling hooks automatically in new repos.
- Markdown lint and link checking remain candidates. The current evidence favors narrow static tests because they directly encode the risky contract and avoid network/link-check noise.
- Go tests, integration tests, daemon startup, migrations, build scripts, install scripts, release/publish actions, and README `curl` commands remain manual or explicitly approved actions when they access network, external services, generated outputs, or repo-specific runtime behavior.
- Subagents remain boundary-based rather than unconditional; L/XL, planned, cross-module, multi-failure and multi-file-review tasks must actively assess them and use them when 2+ independent non-overlapping subtasks exist.

Reject as default for this V2 checkpoint:

- MCP/code graph/memory as always-on defaults.
- Default blocking hooks in the portable toolkit.
- Full Markdown lint/link checker as the default docs repo gate.
- `go test` as a default hook for repos whose project docs prohibit automatic Go tests.

Next review trigger:

- Revisit only after a missed validation, a user correction, or adoption into another representative repo changes the evidence. The current V2 package has enough evidence to keep static docs/content-contract tests as repo-specific candidates without expanding default automation.

## Promotions

Promoted into V2:

- `install.sh --repo-only`
  - Evidence: multi-repo dry-run showed global AGENTS/skills checks create noise when only repo context pack is needed.
  - Validation: `test_install_repo_only_skips_global_files`; temporary release install drill.
  - Boundary: requires `--repo PATH`; skips global writes.

- `scripts/audit_repo_adoption.py`
  - Evidence: external repo adoption needs a reusable read-only preflight before writing context pack files.
  - Validation: `tests/test_audit_repo_adoption.py` including dirty worktree detection, machine-readable `--json` output, and evidence-ready `--markdown` output.
  - Boundary: read-only audit; does not replace `install.sh --dry-run`.

- `scripts/render_usage_row.py`
  - Evidence: V2 adoption requires every installed repo to record a baseline row before collecting real task evidence.
  - Validation: `tests/test_render_usage_row.py` including default row rendering, Markdown escaping, date default, and verification command override.
  - Boundary: prints rows only; does not write `docs/codex-usage.md` by itself.

- `docs/architecture.md` as a required context pack file
  - Evidence: quickstart and template assume architecture docs exist, but verifier did not enforce it.
  - Validation: `test_check_context_pack_requires_architecture_document`.
  - Boundary: checks only context pack completeness; does not validate architecture quality.

- Static docs/content-contract tests as repo-specific gate candidates
  - Evidence: `ai-workflows` protected README append guards and fail-fast raw downloads; `dify-plugin-daemon` protected manual-only test policy and stale documented repo paths.
  - Validation: red -> green static pytest tests in both calibrated repos; toolkit verifier requires this evidence and template guidance.
  - Boundary: not a global hook, not full Markdown lint, not external link checking; candidate tests must be narrow, fast, local-only, and tied to a repeated repo contract.

## Rejections

Rejected as V2 defaults:

- Blocking hooks by default.
  - Reason: evidence supports documentation and candidate evaluation, not automatic repo-wide blocking.

- MCP/code graph/memory by default.
  - Reason: current evidence shows repo docs, `rg`, language tools and targeted tests solve most observed context problems.

- Unbounded subagents as the default implementation mode.
  - Reason: subagents are useful with clear ownership and now require proactive suitability checks for large/planned/cross-module work, but shared files, lifecycle, schemas and product semantics remain main-agent controlled.

- Browser QA for every frontend change.
  - Reason: pure JS contract changes can be validated cheaply; browser QA remains required for layout, CSS, interaction, route, media, canvas/chart or viewport risk.

## Deferred Work

External repo baseline installation and repo-specific onboarding calibration are no longer deferred for the two safe candidates:

```text
/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows
/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon
```

`/Users/wujunwei/Desktop/coze-studio` should still be reviewed first because it has uncommitted changes.

After its local changes are reviewed, rerun:

```bash
python3 scripts/audit_repo_adoption.py /Users/wujunwei/Desktop/coze-studio
```

Next V2 evidence gap: apply the toolkit to another representative repo only after its dirty worktree or existing `AGENTS.md` conflict is reviewed, then compare whether the same static docs/content-contract pattern still holds.

## Final V2 Completion Audit

本节按 V2 adoption plan 的 10 个阶段审计当前完成度。结论只基于当前文件、release artifact 和本轮新鲜验证，不基于意图或记忆。

| Plan stage | Evidence | Conclusion |
|---|---|---|
| Freeze V1 baseline | `scripts/verify_toolkit.py`、release checksum、`implementation-plan` 仅作为 removed skill 边界出现 | Satisfied |
| Select representative trial repos | 扫描 5 个候选 repo；`ai-workflows` 和 `dify-plugin-daemon` 完成安装和校准；有冲突/dirty repo 保持 manual merge | Satisfied with conservative scope |
| Run real M/L/XL tasks | 两个校准外部 repo 有 5 条真实 M 级任务记录；`ai-quant-trading` 另有 5 条真实试跑和 5 条实现任务记录作为旁证 | Satisfied |
| First adoption review | `First Adoption Review` 基于前 3 条 M 级任务，晋升 context verifier 和窄静态测试候选，拒绝默认 hooks/MCP/subagents | Satisfied |
| Evaluate hooks candidates | `docs/quality-gates.md` 模板和各 trial repo 记录将 context verifier、targeted tests、静态文档契约测试列为候选；未启用 blocking hooks | Satisfied: documented candidates, no default hook |
| Evaluate MCP/code graph/memory | 证据显示 repo docs、`rg`、语言工具和 targeted tests 解决当前观察到的问题；无重复失败支持默认启用 | Satisfied by rejection/default-defer decision |
| Evaluate subagents | `ai-quant-trading` 完成只读 subagent 边界校准；post-V2 refinement 将大型/计划/跨模块任务升级为主动 suitability check，安全拆分时主动使用 | Satisfied by proactive boundary |
| Browser/frontend QA calibration | `ai-quant-trading` 证据支持前端契约测试与 browser QA 触发条件分离；V2 review 保持 browser QA conditional | Satisfied by trigger calibration |
| Prepare V2 toolkit update | `VERSION` 为 `2026.06.07.9`；`WORKFLOW-REVIEW.md`、`QUICKSTART.md`、repo-template docs、verifier/tests 和 release 已更新 | Satisfied |
| Final verification and migration drill | toolkit self-check、toolkit tests、repo-template checks、checksum、final temporary install drill、trial repo checks 均有新鲜通过输出 | Satisfied |

Final decision:

- V2 end state is achieved as an evidence-driven portable package, not as a maximal automation package.
- Promoted by evidence: repo-only install, adoption audit/render helpers, required architecture context, context pack verifier, static docs/content-contract tests as repo-specific candidates.
- Deliberately not defaulted: blocking hooks, MCP/code graph/memory, unbounded subagents, browser QA, Go tests, full Markdown lint, link checking, external install/download commands. Subagents are now proactively evaluated for L/XL, planned, cross-module, multi-failure and multi-file-review work.
- Remaining work is future adoption scope, not a blocker for V2: apply the kit to another representative repo after its dirty worktree or existing instruction conflicts are reviewed.

## Current V2 Status

`2026.06.07.9` is a V2 adoption package candidate with evidence-backed repo-only installation, read-only adoption audit, required architecture context, evidence-ready audit reporting, two verified external baseline installs, repo-specific onboarding calibration for a docs-only workflow repo plus a Go service/CLI repo, five real calibrated-repo M-level task records, the first adoption review, the second adoption review, and post-V2 proactive subagent guidance. Static docs/content-contract tests are promoted as repo-specific gate candidates in the template guidance. Hooks, MCP/code graph/memory, browser QA, Go tests, Markdown lint, and link checking remain conditional rather than default automation; subagents are actively evaluated for L/XL, planned, cross-module, multi-failure and multi-file-review work, and used when 2+ independent non-overlapping subtasks exist.
