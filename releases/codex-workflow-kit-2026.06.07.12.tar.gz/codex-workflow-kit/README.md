# Codex Workflow Kit

这是一套用于增强个人 Codex 工作流的可迁移工具包，包含全局规则、repo context pack 模板、个人 skills、安装脚本、自检脚本和发布归档脚本。

## 目录

```text
VERSION
MANIFEST.sha256
QUICKSTART.md
WORKFLOW-REVIEW.md
docs/
  V2-ADOPTION-EVIDENCE.md
  superpowers/
    plans/
      2026-06-07-workflow-kit-v2-adoption.md
      2026-06-07-workflow-kit-v2-1-observability-subagents-mcp.md

global/
  AGENTS.md

install.sh

scripts/
  audit_repo_adoption.py
  render_usage_row.py
  verify_toolkit.py
  build_release.py

repo-template/
  AGENTS.md
  scripts/
    verify_context_pack.py
  tests/
    test_verify_context_pack.py
  docs/
    architecture.md
    commands.md
    testing.md
    quality-gates.md
    subagents.md
    observability.md
    mcp-pilot.md
    codex-usage.md
    codex-playbook.md
    glossary.md
    decisions/
      README.md
      0001-template.md
    specs/
      README.md
      0001-template.md

skills/
  repo-onboarding/
  spec-kit-xl/
  debug-loop/
  frontend-qa/
  decision-record/
  completion-review/
  security-review/
  dependency-upgrade-review/
  research-brief/
```

## 用法

`QUICKSTART.md` 是最终交付清单，包含新机器最短安装命令、验证命令、以及首次应用到新 repo 的 10 分钟流程。

`WORKFLOW-REVIEW.md` 是一页总复盘，记录最终路线、完成状态、可复用能力、候选边界、新机器演练结果和后续触发条件。迁移或继续扩展前，先读它确认当前边界。

`docs/superpowers/plans/2026-06-07-workflow-kit-v2-adoption.md` 是 V1 之后的详细后续计划，用于真实 repo 采用、效果评估、hooks/MCP/memory/subagents 候选晋升和 V2 打包。

`docs/superpowers/plans/2026-06-07-workflow-kit-v2-1-observability-subagents-mcp.md` 是 V2.1 的详细计划，用于新增 observability、subagent prompt cards、MCP/code graph pilot 和 `render_usage_row.py pilot`，同时保持 no default automation。

`docs/V2-ADOPTION-EVIDENCE.md` 是 V2 当前证据包，记录 baseline 验证、候选 repo dry-run、已晋升能力、拒绝默认化能力、外部 repo baseline 安装和 repo-specific onboarding calibration。

### 1. 先验证 toolkit 包

在新机器或复制后的目录里，先运行：

```bash
python3 scripts/verify_toolkit.py
```

期望输出：

```text
Workflow toolkit OK
```

这个检查会确认：

- 全局 `AGENTS.md`、repo 模板、9 个个人 skills 都在包里。
- `implementation-plan` 没有重新出现，避免和 Superpowers 计划职责冲突。
- repo 模板自带的 `scripts/verify_context_pack.py` 可以通过。
- 包里没有 `__pycache__`、`.pytest_cache`、`.pyc` 等生成缓存。
- 文档里没有明显凭证模式。
- `MANIFEST.sha256` 和当前文件内容一致。

如果要运行 toolkit 自身测试，需要使用已安装 `pytest` 的 Python 环境：

```bash
python3 -m pytest tests/test_verify_toolkit.py -q
cd repo-template
python3 -m pytest tests/test_verify_context_pack.py -q
```

两组测试的工作目录不同：toolkit 测试在包根目录运行，repo context pack 测试在 `repo-template/` 目录运行。

### 2. 构建可迁移发布包

目录可以直接复制，也可以构建带 checksum 的归档包：

```bash
python3 scripts/build_release.py
```

输出位置：

```text
releases/codex-workflow-kit-<VERSION>.tar.gz
releases/codex-workflow-kit-<VERSION>.tar.gz.sha256
```

归档包内容包含 `VERSION` 和 `MANIFEST.sha256`。换机器后可以解压并先运行：

```bash
python3 scripts/verify_toolkit.py
```

如果要校验归档文件本身：

```bash
cd releases
shasum -a 256 -c codex-workflow-kit-<VERSION>.tar.gz.sha256
```

### 3. 一键安装到当前机器

先 dry-run，看会写哪些文件：

```bash
./install.sh --dry-run
```

确认后安装全局 Codex 宪法和个人 skills：

```bash
./install.sh
```

默认行为是非破坏式：如果目标位置已经有不同内容，脚本会停止并提示冲突。需要保留旧文件再替换时使用：

```bash
./install.sh --backup
```

只在确认要覆盖时使用：

```bash
./install.sh --force
```

如果要安装到自定义位置，适合测试或迁移演练：

```bash
./install.sh --codex-home /tmp/codex-home --agents-home /tmp/agents-home
```

### 4. 全局 Codex 宪法

`global/AGENTS.md` 是个人全局工作原则。安装脚本会把它放到 Codex home 的 `AGENTS.md`。

安装位置：

```text
~/.codex/AGENTS.md
```

### 5. Repo context pack 模板

`repo-template/` 是项目级模板。复制到目标仓库根目录后，根据项目实际情况填写。

项目 `AGENTS.md` 只写项目事实、项目规则、项目边界和验证矩阵，不重复全局宪法。

落地到已有仓库时要合并而不是机械覆盖：先检查是否已经存在同类文档或大小写等价文件，例如已有 `docs/ARCHITECTURE.md` 时，不再创建重复的 `docs/architecture.md`，而是在 `AGENTS.md` 和相关 docs 中索引现有文件。

模板自带 `scripts/verify_context_pack.py` 和 `tests/test_verify_context_pack.py`。复制到新仓库后，先按目标仓库真实 Python 入口调整命令，再运行 context pack 验证，确认文件、命令、架构文档引用和敏感模式检查可用。

安装位置：

```text
<repo>/
  AGENTS.md
  scripts/
  tests/
  docs/
```

也可以让安装脚本把 repo 模板复制到目标仓库：

```bash
./install.sh --repo /path/to/repo --dry-run
./install.sh --repo /path/to/repo --backup
```

落地前可以先做只读 adoption audit，判断适合 repo-only 安装还是人工合并：

```bash
python3 scripts/audit_repo_adoption.py /path/to/repo
```

批量审计或需要机器可读输出时使用：

```bash
python3 scripts/audit_repo_adoption.py --json /path/to/repo-a /path/to/repo-b
```

需要直接生成 adoption evidence 表格时使用：

```bash
python3 scripts/audit_repo_adoption.py --markdown /path/to/repo-a /path/to/repo-b
```

安装并验证 context pack 后，可以生成一行标准 baseline usage 记录，再追加到目标 repo 的 `docs/codex-usage.md`：

```bash
python3 scripts/render_usage_row.py baseline
python3 scripts/render_usage_row.py baseline --verification-command ".venv/bin/python scripts/verify_context_pack.py"
python3 scripts/render_usage_row.py pilot --pilot observability
python3 scripts/render_usage_row.py pilot --pilot subagents
python3 scripts/render_usage_row.py pilot --pilot mcp-code-graph
```

`pilot` 子命令只打印 Markdown 行，用于把可选工具试点记录到 `docs/codex-usage.md`；它不会写目标 repo、安装外部工具、启用 hooks 或启动 MCP。

如果全局 `AGENTS.md` 和个人 skills 已安装，只想给新仓库落地 context pack，使用更安静、写入面更小的 repo-only 模式：

```bash
./install.sh --repo-only --repo /path/to/repo --dry-run
./install.sh --repo-only --repo /path/to/repo --backup
```

落地到已有仓库时，优先使用 `--dry-run` 看冲突。脚本不会自动覆盖已有不同文件；如果目标仓库已经有大小写等价的架构文档，例如 `docs/ARCHITECTURE.md`，脚本会停止，要求人工合并引用，避免创建重复文档。

### 6. 个人 skills

`skills/` 包含 9 个个人 Codex skills：

- `repo-onboarding`：为仓库建立 context pack。
- `spec-kit-xl`：为 XL/正式规格任务沉淀需求、非目标、验收标准和风险边界。
- `debug-loop`：失败后按观察、假设、修复、复测循环收敛。
- `frontend-qa`：前端真实浏览器/截图/移动端/状态验证。
- `decision-record`：长期技术取舍沉淀成 ADR。
- `completion-review`：测试和验证之后、最终回复之前的交付闸门。
- `security-review`：安全敏感代码、配置、依赖、hooks、MCP/plugin、CI 或信任边界变化时做专项审查。
- `dependency-upgrade-review`：依赖、lockfile、runtime/base image、GitHub Actions、CVE/advisory、license 或供应链风险变更时做专项审查。
- `research-brief`：评估 GitHub 仓库、skills、MCP、hooks、subagents、模型/API 或工具选型时形成证据化 promote/hold/reject 结论。

这些 skills 设计为补充 Superpowers：`spec-kit-xl` 只做 XL/正式规格，`security-review`、`dependency-upgrade-review`、`research-brief` 只做专项审查/研究，计划、TDD、阶段推进和执行仍交给 Superpowers。

安装位置：

```text
~/.agents/skills/
```

复制后应确认 Codex 的 skill 列表能看到：

```text
repo-onboarding
spec-kit-xl
debug-loop
frontend-qa
decision-record
completion-review
security-review
dependency-upgrade-review
research-brief
```

## 新机器落地顺序

推荐按这个顺序执行：

```bash
cd codex-workflow-kit
python3 scripts/verify_toolkit.py
python3 scripts/build_release.py
./install.sh --dry-run
./install.sh
```

如果还要给某个仓库安装 context pack：

```bash
./install.sh --repo /path/to/repo --dry-run
./install.sh --repo /path/to/repo --backup
cd /path/to/repo
python3 scripts/verify_context_pack.py
```

如果目标仓库没有 `python3` 或使用虚拟环境，把最后一条命令替换成项目真实入口，例如：

```bash
.venv/bin/python scripts/verify_context_pack.py
```

## 试跑和效果评估

给新仓库安装 context pack 后，不要立刻启用整套 hooks、MCP 或 memory。subagents 按全局协议主动评估：L/XL、已有实施计划、跨模块、多独立失败源、多文件审查和可并行调查要先做 suitability check；存在 2 个以上独立非重叠子任务时主动使用，不使用时说明原因。推荐先做 3-5 个真实 M/L/XL 任务，把结果写入：

```text
docs/codex-usage.md
```

每条记录只保留可复用信号：用了什么流程、跑了什么验证、减少了什么误判或返工、暴露了什么副作用或成本。

完成 3-5 条后做一次阶段复盘：

- 保留连续带来收益的规则或验证路径。
- 把一次性经验留在记录中观察，不晋升为全局规则。
- hooks、MCP、memory 和新脚本先作为文档化候选，只有在重复证明有收益、边界清晰、可回退后再启用；subagents 保持边界驱动，不做共享状态无条件并行。
- 如果流程只是弥补文档缺失，优先更新 `AGENTS.md`、`docs/testing.md`、`docs/quality-gates.md` 或 `docs/codex-playbook.md`。

## 复用检查清单

换机器或迁移到新 Codex 环境时，确认：

- `python3 scripts/verify_toolkit.py` 输出 `Workflow toolkit OK`。
- `python3 scripts/build_release.py` 已生成 `releases/codex-workflow-kit-<VERSION>.tar.gz` 和 `.sha256`。
- `./install.sh --dry-run` 的计划符合预期。
- `global/AGENTS.md` 已复制到 `~/.codex/AGENTS.md`。
- `skills/*` 已复制到 `~/.agents/skills/`。
- 新仓库已复制 `repo-template/AGENTS.md`、`repo-template/docs/`、`repo-template/scripts/`，以及可选的 `repo-template/tests/`。
- Codex 可发现 9 个个人 skills。
- repo `AGENTS.md` 没有重复全局宪法，只保留项目事实和边界。
- 已检查目标仓库是否有同类文档或大小写等价文件，避免重复创建或覆盖人工文档。
- `docs/commands.md`、`docs/testing.md`、`docs/quality-gates.md` 已按项目真实命令填写。
- context pack verifier 已用目标仓库真实解释器运行通过。
- `docs/codex-usage.md` 已按真实任务记录效果信号，不记录一次性过程或敏感信息。
- `docs/specs/` 只用于 XL/正式规格任务。
- 没有把凭证、token、私钥、生产数据或一次性调试过程写入模板、docs 或 memory。

## 当前落地阶段

已完成：

- 个人 Codex 宪法和任务分级协议。
- repo context pack 模板。
- Superpowers/spec-kit 总控协议。
- 9 个自定义核心/专项 skills。
- MCP、代码图谱和 memory 的使用边界协议。
- hooks 质量门禁协议和 repo 模板。
- subagents 并行协议和 repo 模板。
- usage/效果评估协议和 repo 模板。
- 真实仓库 5 个 M 级样本试跑，并将验证副作用分级回灌到 repo 模板。
- hooks 候选集策略：默认只文档化，不自动启用；默认阻断 hooks 只考虑 A 级无写入/低副作用命令。

当前盘点：

- 已启用插件：Browser、Chrome、Computer Use、Documents、Spreadsheets、Presentations、Superpowers。
- 显式 MCP server：内建 `node_repl`。
- memory：Codex 本地存在内建 memory 状态；当前不新增自定义 memory server。
- 代码图谱：当前不安装额外代码图谱服务；先使用 `rg`、语言工具、测试和 repo docs 构建临时图谱。

下一阶段：

- 按 `docs/superpowers/plans/2026-06-07-workflow-kit-v2-adoption.md` 进入 V2 采用周期：选择 3-5 个代表性 repo，累计真实 M/L/XL 任务记录，再决定哪些门禁可以前移到 hooks、哪些必须保持人工触发。

## 已校准的复盘结论

- `scripts/verify_context_pack.py` 适合做 A 级低副作用文档/context pack 门禁。
- 静态扫描和覆盖率这类会写 `test-results/`、coverage、trace 或截图的命令属于 B 级报告门禁；只有输出目录已忽略且成本可控时才前移。
- 通过 TestClient、dev server、preview server 或 app startup 做 health check 的命令属于 C 级应用生命周期门禁；即使不连接外部服务，也可能初始化本地数据库、启动调度器、写缓存、占用端口或生成报告，不应默认放入 hooks。
- 外部服务、真实数据同步、数据库迁移、部署、权限、交易、支付、生产或凭证相关命令属于 D 级高风险门禁，执行前需要用户确认。
- Compile/typecheck/lint 也要先确认是否会写 bytecode、cache、coverage、build 产物或自动格式化文件；会写产物的命令不应标成严格无写入 hook。
