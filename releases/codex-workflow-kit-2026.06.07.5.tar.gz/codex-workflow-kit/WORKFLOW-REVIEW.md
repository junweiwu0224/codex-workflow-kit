# Workflow Review

本文件记录这套 Codex Workflow Kit 的最终路线、完成状态、可复用范围、仍保持候选的能力，以及后续真实使用时的触发条件。

## 最终路线

```text
个人 Codex 宪法
-> 任务分级协议
-> repo context pack
-> Superpowers/spec-kit
-> 自定义核心 skills
-> MCP/代码图谱/memory
-> hooks 质量门禁
-> subagents 并行
-> usage/效果评估
-> real repo trial runs
-> 新机器演练
```

## 完成状态

已完成并打包：

- `global/AGENTS.md`：个人 Codex 宪法、任务分级、Superpowers/spec-kit 总控、MCP/memory/hooks/subagents 边界。
- `repo-template/`：项目级 `AGENTS.md`、commands/testing/quality-gates/subagents/usage/playbook/ADR/specs/glossary 模板。
- `skills/`：`repo-onboarding`、`spec-kit-xl`、`debug-loop`、`frontend-qa`、`decision-record`、`completion-review`。
- `install.sh`：非破坏式安装器，支持 dry-run、自定义 Codex/Agents home、repo 模板安装、backup/force。
- `scripts/verify_toolkit.py`：包级自检，覆盖必需文件、manifest、skills、Superpowers 边界、质量门禁模板、usage 复盘机制、生成缓存和敏感模式。
- `scripts/build_release.py`：刷新 `MANIFEST.sha256`，构建 release tarball 和 checksum。

已移除并保持移除：

- `implementation-plan` skill。计划、TDD、阶段推进和执行由 Superpowers 负责，个人 skills 只做专项补强。

## 可复用能力

以下内容已经通过真实仓库试跑和新机器演练，适合直接复用：

- 个人 Codex 宪法和任务分级：XS/S 不过度流程化，M/L/XL 使用 Superpowers 或 `spec-kit-xl`。
- repo context pack 模板：用于快速建立项目事实、命令、测试、架构、质量门禁和 usage 记录。
- context pack verifier：适合作为 A 级低副作用文档/context pack 门禁。
- 自定义核心 skills：作为 Superpowers 的补充，而不是替代总控流程。
- quality-gates 模板：按副作用分层，把 targeted tests 按受影响范围选择，不要求每次全部运行。
- install/release 流程：可在新机器解包、验证、dry-run、安装、重复安装和冲突保护。

## 候选边界

以下能力保持文档化候选，不作为默认动作：

- hooks：默认不启用阻断型 hooks。只有 A 级、短耗时、稳定、无外部依赖、无业务数据写入、无隐藏产物的命令才考虑前移。
- MCP/代码图谱/memory：先用 repo context pack、`rg`、语言工具和测试建立临时上下文；只有重复收益明确、边界清楚、可回退时再增加长期服务。
- subagents：只用于边界清晰、文件 ownership 不重叠、或只读分析能并行的任务；共享入口、schema/storage、应用生命周期、交易/生产路径由主 agent 串行控制。
- `spec-kit-xl`：只用于 XL、正式规格、长期验收标准或用户明确要求规格文档的任务。
- browser/frontend QA：前端布局、CSS、交互、资源加载、跨 viewport 或用户可见风险较高时触发；纯 JS 契约或小 empty-state 改动可先用 targeted tests。

## 真实验证

已完成的验证层：

- toolkit 自检：`scripts/verify_toolkit.py` 输出 `Workflow toolkit OK`。
- repo-template 自检：`repo-template/scripts/verify_context_pack.py repo-template` 输出 `Context pack OK`。
- toolkit tests：覆盖 toolkit 自检、manifest/release、安装器 preflight、质量门禁模板和 workflow review。
- repo-template tests：覆盖 context pack verifier。
- 新机器演练：release checksum 通过；临时解包后 toolkit 自检通过；安装到临时 Codex/Agents/repo 成功；目标 repo context pack 通过；第二次安装跳过相同文件；冲突安装返回失败且不会提前写入 Codex/Agents home。

已校准的副作用判断：

- A 级：context pack verifier、无写入 targeted tests、确认无产物的 lint/typecheck。
- B 级：coverage、静态报告、截图、trace、会写 ignored 报告的扫描。
- C 级：TestClient/app health/dev server/preview server，可能触发应用生命周期、本地 DB、缓存、端口或后台任务。
- D 级：外部服务、真实数据同步、迁移、部署、权限、交易、支付、生产或凭证相关操作。

## 触发条件

在新仓库中按以下方式使用：

- 首次进入仓库且上下文不足：使用 `repo-onboarding` 建立 context pack。
- XS/S 任务：直接读相关文件、做最小改动、跑 targeted verification。
- M 任务：使用 Superpowers 做轻量澄清、TDD/实现和验证；必要时记录 usage 信号。
- L 任务：先调查影响范围，再由 Superpowers 写计划并推进；长期取舍用 `decision-record`。
- XL/正式需求：先用 `spec-kit-xl` 写规格，规格确认后再交给 Superpowers 写计划和执行。
- 测试、构建、启动、E2E 或运行失败：进入 `debug-loop`。
- 前端用户可见风险：使用 `frontend-qa`，必要时浏览器截图或多 viewport 验证。
- 完成实现和验证后：使用 `completion-review` 再最终回复。
- 每 3-5 个代表性任务后：更新 `docs/codex-usage.md`，决定是否把候选晋升到 repo 规则、quality gates、hooks、skills 或 memory。

## 新机器演练

推荐迁移命令：

```bash
cd codex-workflow-kit
python3 scripts/verify_toolkit.py
./install.sh --dry-run
./install.sh
```

给某个仓库安装 context pack：

```bash
./install.sh --repo /path/to/repo --dry-run
./install.sh --repo /path/to/repo --backup
cd /path/to/repo
python3 scripts/verify_context_pack.py
```

默认安装器是非破坏式的：遇到不同内容会先报冲突，不会覆盖。`--backup` 用于保留旧文件后替换，`--force` 只在确认覆盖时使用。

## V2 Adoption Review

Evidence source:

- Baseline toolkit: `python3 scripts/verify_toolkit.py` 输出 `Workflow toolkit OK`；release checksum 输出 `codex-workflow-kit-2026.06.07.5.tar.gz: OK`。
- Trial repo scan: 找到 `ai-quant-trading`、`coze-studio`、`ai-workflows`、`dify`、`dify-plugin-daemon` 5 个候选仓库。
- Dry-run install: `ai-quant-trading` 和 `dify` 因已有 `AGENTS.md` 正确报冲突；`coze-studio` 因 dirty worktree 暂缓。
- Dirty-worktree-aware audit: `ai-workflows` 和 `dify-plugin-daemon` 输出 `repo-only-install`、findings 为 0。
- External baseline install: `ai-workflows` 和 `dify-plugin-daemon` 已完成 `--repo-only --backup` 安装，`python3 scripts/verify_context_pack.py` 输出 `Context pack OK`，并写入 baseline usage row。
- Repo-specific onboarding calibration: `ai-workflows` 已校准为 docs-only workflow repo；`dify-plugin-daemon` 已校准为 Go daemon/CLI repo，并记录 manual-only test policy、runtime 边界、CI 命令和 generated-code 边界。两者复跑 `python3 scripts/verify_context_pack.py` 均输出 `Context pack OK`。
- First calibrated-repo task: `dify-plugin-daemon` 已完成 “Align Go version docs with go.mod/CI”，修正 `CLAUDE.md` stale Go version，并用 targeted `rg` 搜索和 context pack verifier 验证；Go tests 按 repo policy 未自动运行。
- Second calibrated-repo task: `ai-workflows` 已完成 “Guard README agent instruction append snippets”，通过红绿静态测试保护 README 安装命令，避免重复追加 agent 指令。
- Real usage evidence: `ai-quant-trading/docs/codex-usage.md` 已有 context pack、质量门禁、副作用分级、subagents 边界和 5 个真实实现任务记录。

Promotions:

- `install.sh --repo-only`：用于全局工具已安装后，只给新仓库落地 context pack，减少多仓库 dry-run 输出噪音和写入面。
- `repo-template/scripts/verify_context_pack.py`：将 `docs/architecture.md` 纳入必需文件，和 repo 模板、Quickstart、AGENTS 引用保持一致。
- `scripts/audit_repo_adoption.py`：提供只读 repo adoption preflight，在写入目标 repo 前区分 `repo-only-install` 和 `manual-merge`，并检查 dirty worktree。
- `scripts/render_usage_row.py`：生成标准 baseline usage 行，安装后可追加到目标 repo 的 `docs/codex-usage.md`，减少多 repo 首次采用记录漂移。

Rejections:

- 不把 hooks 默认启用；当前证据支持候选集和 side-effect audit，不支持阻断型自动启用。
- 不把 MCP/code graph/memory 默认启用；当前证据显示多数问题可先用 repo docs、`rg`、语言工具和 targeted tests 解决。
- 不把 subagents 设为默认实现路径；只在边界清晰、文件 ownership 不重叠或只读分析可并行时使用。

Remaining candidates:

- 在已校准的 `ai-workflows` 和 `dify-plugin-daemon` 中继续执行 1-3 条真实 M/L/XL 任务，累计 3-5 条后做首次 adoption review。
- 对已有 `AGENTS.md` 的大型 repo，优先人工合并而不是 `--backup` 机械替换。
- 如果两个以上真实 repo 都证明同一条规则稳定减少误判，再考虑升级到全局 `AGENTS.md` 或个人 skill。
