import re

from scripts.render_usage_row import build_baseline_row, main


def test_build_baseline_row_uses_defaults():
    row = build_baseline_row(date="2026-06-07")

    assert row == (
        "| 2026-06-07 | Baseline context pack install | M | repo-onboarding, context pack verifier | "
        "`python3 scripts/verify_context_pack.py` -> Context pack OK | "
        "Repo has portable commands/testing/quality docs; no hooks enabled yet | "
        "Collect 3-5 real task records before promotion |"
    )


def test_build_baseline_row_escapes_markdown_cells():
    row = build_baseline_row(
        date="2026-06-07",
        task="Baseline | context pack",
        effect="Docs ready\nNo hooks",
    )

    assert "Baseline \\| context pack" in row
    assert "Docs ready No hooks" in row


def test_main_prints_baseline_row_with_today(capsys):
    exit_code = main(["baseline"])
    output = capsys.readouterr().out.strip()

    assert exit_code == 0
    assert re.match(r"^\| 20[0-9]{2}-[0-9]{2}-[0-9]{2} \| Baseline context pack install \|", output)
    assert "`python3 scripts/verify_context_pack.py` -> Context pack OK" in output


def test_main_prints_baseline_row_with_overrides(capsys):
    exit_code = main(
        [
            "baseline",
            "--date",
            "2026-06-07",
            "--verification-command",
            ".venv/bin/python scripts/verify_context_pack.py",
            "--verification-result",
            "Context pack OK",
        ]
    )
    output = capsys.readouterr().out

    assert exit_code == 0
    assert "| 2026-06-07 | Baseline context pack install | M |" in output
    assert "`.venv/bin/python scripts/verify_context_pack.py` -> Context pack OK" in output
