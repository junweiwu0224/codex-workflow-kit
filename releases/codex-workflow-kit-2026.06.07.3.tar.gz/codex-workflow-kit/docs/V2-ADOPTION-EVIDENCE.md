# V2 Adoption Evidence

本文件记录 Codex Workflow Kit V2 采用计划的当前证据。目标是让每个晋升、拒绝和暂缓决定都有可审计依据，而不是凭主观感觉扩大默认自动化。

## Baseline Verification

已验证的 V2 baseline：

```bash
python3 scripts/verify_toolkit.py
# Workflow toolkit OK

/Users/wujunwei/Desktop/ai-quant-trading/.venv/bin/python -m pytest -p no:cacheprovider tests/test_audit_repo_adoption.py tests/test_render_usage_row.py tests/test_verify_toolkit.py -q
# 34 passed

cd repo-template
python3 scripts/verify_context_pack.py
# Context pack OK

/Users/wujunwei/Desktop/ai-quant-trading/.venv/bin/python -m pytest -p no:cacheprovider tests/test_verify_context_pack.py -q
# 12 passed

cd releases
env LC_ALL=C LANG=C LC_CTYPE=C shasum -a 256 -c codex-workflow-kit-2026.06.07.3.tar.gz.sha256
# codex-workflow-kit-2026.06.07.3.tar.gz: OK
```

临时解包演练：

```text
Workflow toolkit OK
global dry-run/install completed against temporary Codex and agents homes
installed AGENTS.md and repo-onboarding skill verified
repo-only dry-run/install completed against a temporary repo
Context pack OK
baseline usage row appended and found in docs/codex-usage.md
```

## Trial Repo Scan

只读扫描找到 5 个候选仓库：

| Repo | Shape | Existing context | Dry-run result | Current decision |
|---|---|---|---|---|
| `/Users/wujunwei/Desktop/ai-quant-trading` | Python + frontend/dashboard | 已有 `AGENTS.md` 和 context docs | `AGENTS.md` conflict | Use as evidence source; do not overwrite |
| `/Users/wujunwei/Desktop/coze-studio` | Go backend repo | No root context pack found | Dirty worktree; can create repo context pack after review | Manual merge until local changes are reviewed |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Docs/tooling repo | V2 context pack installed and repo-specific calibration completed | `Context pack OK` | Ready for real workflow doc task records |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify` | Large multi-package app | Existing root and nested `AGENTS.md` files | `AGENTS.md` conflict | Manual merge only; no mechanical install |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Go service/plugin daemon | V2 context pack installed and repo-specific calibration completed | `Context pack OK` | Ready for real code task records; Go tests remain manual-only by repo policy |

只读 adoption audit 命令：

```bash
python3 scripts/audit_repo_adoption.py /path/to/repo
python3 scripts/audit_repo_adoption.py --json /path/to/repo-a /path/to/repo-b
python3 scripts/audit_repo_adoption.py --markdown /path/to/repo-a /path/to/repo-b
```

该脚本只读取目标 repo，输出 `repo-only-install` 或 `manual-merge` 建议，不复制模板、不写文件、不创建备份。`--json` 输出用于批量 adoption 和后续自动化评估；`--markdown` 输出可直接粘贴为 adoption evidence 表格，减少手工整理误差。

Baseline usage row 生成命令：

```bash
python3 scripts/render_usage_row.py baseline
python3 scripts/render_usage_row.py baseline --verification-command ".venv/bin/python scripts/verify_context_pack.py"
```

该脚本只打印 Markdown 表格行，不写目标 repo。安装和验证 context pack 后，可把输出追加到目标 repo 的 `docs/codex-usage.md`，减少多 repo 首次采用记录的手工漂移。

安装前 audit 结果：

| Repo | Recommendation | Findings | Command |
|---|---|---|---|
| `/Users/wujunwei/Desktop/ai-quant-trading` | `manual-merge` | `architecture-case-match`, `dirty-worktree`, `existing-agents`, `existing-context-file` x12 | `./install.sh --repo-only --repo /Users/wujunwei/Desktop/ai-quant-trading --backup` |
| `/Users/wujunwei/Desktop/coze-studio` | `manual-merge` | `dirty-worktree` | `./install.sh --repo-only --repo /Users/wujunwei/Desktop/coze-studio --backup` |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | `repo-only-install` | 0 | `./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows --backup` |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify` | `manual-merge` | `dirty-worktree`, `existing-agents` | `./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify --backup` |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | `repo-only-install` | 0 | `./install.sh --repo-only --repo /Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon --backup` |

安装和校准后再次 audit，两个已落地 repo 会因为已有 `AGENTS.md`、context docs 和 dirty worktree 正确返回 `manual-merge`。这表示后续更新应人工合并，而不是重复机械安装。

## Real Usage Evidence

`/Users/wujunwei/Desktop/ai-quant-trading/docs/codex-usage.md` already contains:

- Context pack onboarding evidence.
- Quality gate side-effect calibration.
- Hooks candidate design.
- Subagents parallel boundary calibration.
- Five real implementation task records.
- Phase reviews after representative tasks.

Reusable signals from that repo:

- `scripts/verify_context_pack.py` is a strong A-level low-side-effect gate.
- Targeted pytest works best when selected by affected scope.
- Report-writing scans and TestClient/app health checks should not be default hooks.
- Subagents help in read-only or disjoint-ownership work, but should not become default implementation behavior.
- Small frontend JS contract changes can often use Node/pytest contract tests; layout/CSS/interaction risk still needs browser QA.

External repo baseline installs completed after explicit user approval:

| Repo | Verification | Usage record | Git status |
|---|---|---|---|
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | `python3 scripts/verify_context_pack.py` -> Context pack OK | Baseline row added to `docs/codex-usage.md` | New context pack files only |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | `python3 scripts/verify_context_pack.py` -> Context pack OK | Baseline row added to `docs/codex-usage.md` | New context pack files only |

Repo-specific onboarding calibration completed after baseline install:

| Repo | Calibration | Verification | Reusable signal |
|---|---|---|---|
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows` | Replaced generic app-template assumptions with docs-only workflow repo facts in `AGENTS.md` and context docs | `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Lightweight docs/tooling repos should keep commands and gates focused on Markdown/context verification rather than app/build assumptions |
| `/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon` | Replaced generic template assumptions with Go daemon/CLI facts, runtime boundaries, CI commands, generated-code boundaries, and manual-only test policy | `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_context_pack.py` -> Context pack OK | Repo policy can override default Codex verification behavior; record exact Go test commands but do not run them automatically when project docs prohibit it |

## Promotions

Promoted into V2:

- `install.sh --repo-only`
  - Evidence: multi-repo dry-run showed global AGENTS/skills checks create noise when only repo context pack is needed.
  - Validation: `test_install_repo_only_skips_global_files`; temporary release install drill.
  - Boundary: requires `--repo PATH`; skips global writes.

- `scripts/audit_repo_adoption.py`
  - Evidence: external repo adoption needs a reusable read-only preflight before writing context pack files.
  - Validation: `tests/test_audit_repo_adoption.py` including dirty worktree detection, machine-readable `--json` output, and evidence-ready `--markdown` output.
  - Boundary: read-only audit; does not replace `install.sh --dry-run`.

- `scripts/render_usage_row.py`
  - Evidence: V2 adoption requires every installed repo to record a baseline row before collecting real task evidence.
  - Validation: `tests/test_render_usage_row.py` including default row rendering, Markdown escaping, date default, and verification command override.
  - Boundary: prints rows only; does not write `docs/codex-usage.md` by itself.

- `docs/architecture.md` as a required context pack file
  - Evidence: quickstart and template assume architecture docs exist, but verifier did not enforce it.
  - Validation: `test_check_context_pack_requires_architecture_document`.
  - Boundary: checks only context pack completeness; does not validate architecture quality.

## Rejections

Rejected as V2 defaults:

- Blocking hooks by default.
  - Reason: evidence supports documentation and candidate evaluation, not automatic repo-wide blocking.

- MCP/code graph/memory by default.
  - Reason: current evidence shows repo docs, `rg`, language tools and targeted tests solve most observed context problems.

- Subagents as default implementation mode.
  - Reason: subagents are useful with clear ownership, but shared files, lifecycle, schemas and product semantics remain main-agent controlled.

- Browser QA for every frontend change.
  - Reason: pure JS contract changes can be validated cheaply; browser QA remains required for layout, CSS, interaction, route, media, canvas/chart or viewport risk.

## Deferred Work

External repo baseline installation and repo-specific onboarding calibration are no longer deferred for the two safe candidates:

```text
/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/ai-workflows
/Users/wujunwei/Documents/Codex/2026-06-06/agents/work/dify-plugin-daemon
```

`/Users/wujunwei/Desktop/coze-studio` should still be reviewed first because it has uncommitted changes.

After its local changes are reviewed, rerun:

```bash
python3 scripts/audit_repo_adoption.py /Users/wujunwei/Desktop/coze-studio
```

Next V2 evidence gap: run real M/L/XL tasks in the newly installed and calibrated repos, append task rows to `docs/codex-usage.md`, and do the first adoption review after 3-5 representative records.

## Current V2 Status

`2026.06.07.3` is a V2 adoption package candidate with evidence-backed repo-only installation, read-only adoption audit, required architecture context, evidence-ready audit reporting, two verified external baseline installs, and repo-specific onboarding calibration for a docs-only workflow repo plus a Go service/CLI repo. It is not yet the full end-state of the V2 plan because multi-repo real M/L/XL task records and first adoption reviews are still pending.
